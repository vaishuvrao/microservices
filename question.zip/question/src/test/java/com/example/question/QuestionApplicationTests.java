package com.example.question;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
