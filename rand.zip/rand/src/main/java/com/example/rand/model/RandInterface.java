package com.example.rand.model;

public interface RandInterface {
    public void randGen(String size, String origin, String bound);
}
